
export function compareTopSongs(songList1, songList2) {
    
}